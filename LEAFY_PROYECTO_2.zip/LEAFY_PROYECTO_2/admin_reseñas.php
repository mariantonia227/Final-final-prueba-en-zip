<?php
session_start();
require_once("php/conexion.php");

/* =========================
   VALIDAR ADMIN
========================= */

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];

$resultUser = $enlace->query("
SELECT *
FROM usuarios
WHERE email='$email'
");

$user = $resultUser->fetch_assoc();

/* =========================
   ESTADÍSTICAS
========================= */

$stats = $enlace->query("
SELECT
AVG(calificacion) AS promedio,
COUNT(*) AS total,
COUNT(DISTINCT id_negocio) AS negocios
FROM reseñas_negocios
");

$datos = $stats->fetch_assoc();

/* =========================
   TODAS LAS RESEÑAS
========================= */

$reseñas = $enlace->query("
SELECT
r.*,
u.nombre AS usuario,
n.nombre_negocio

FROM reseñas_negocios r

INNER JOIN usuarios u
ON r.id_usuario = u.id_usuarios

INNER JOIN negocios n
ON r.id_negocio = n.id_negocios

ORDER BY r.fecha DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reseñas | Leafy Admin</title>

<link rel="stylesheet" href="css/admin_leafy.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

<style>

.stats{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:20px;
    margin-bottom:30px;
}

.card{
    background:#fff;
    padding:25px;
    border-radius:18px;
    box-shadow:0 4px 12px rgba(0,0,0,.05);
}

.card h3{
    color:#777;
    font-size:14px;
    margin-bottom:10px;
}

.card span{
    font-size:32px;
    font-weight:700;
}

.tabla-container{
    background:#fff;
    padding:25px;
    border-radius:18px;
    box-shadow:0 4px 12px rgba(0,0,0,.05);
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    text-align:left;
    padding:15px;
    background:#f5f5f5;
}

table td{
    padding:15px;
    border-bottom:1px solid #eee;
}

.sin-reseñas{
    text-align:center;
    padding:50px;
    color:#777;
}

.sin-reseñas i{
    font-size:50px;
    margin-bottom:15px;
}

</style>

</head>

<body>

<div class="sidebar">

    <div class="logo">Leafy</div>

    <a href="admin_leafy.php">
        <i class="fa-solid fa-chart-line"></i> Dashboard
    </a>

    <a href="admin_usuarios.php">
        <i class="fa-solid fa-users"></i> Usuarios
    </a>

    <a href="admin_negocios.php">
        <i class="fa-solid fa-store"></i> Negocios
    </a>

    <a href="admin_reseñas.php">
        <i class="fa-solid fa-star"></i> Reseñas
    </a>

    <a href="admin_productos.php">
        <i class="fa-solid fa-shirt"></i> Productos
    </a>

    <a href="admin_comentarios.php">
        <i class="fa-solid fa-comments"></i> Comentarios
    </a>

    <a href="admin_reportes.php">
        <i class="fa-solid fa-flag"></i> Reportes
    </a>

    <a href="php/logout.php">
        <i class="fa-solid fa-right-from-bracket"></i> Salir
    </a>

</div>

<div class="main">

    <div class="topbar">

        <div>
            <h1>Reseñas</h1>
            <p>Opiniones y calificaciones de los negocios</p>
        </div>

        <div class="perfil-admin">
            <?php echo $_SESSION['nombre']; ?>
        </div>

    </div>

    <!-- ESTADÍSTICAS -->

    <div class="stats">

        <div class="card">
            <h3>Calificación promedio</h3>
            <span>
                <?php echo ($datos['promedio']) ? number_format($datos['promedio'],1) : 0; ?>
            </span>
        </div>

        <div class="card">
            <h3>Total reseñas</h3>
            <span>
                <?php echo $datos['total']; ?>
            </span>
        </div>

        <div class="card">
            <h3>Negocios calificados</h3>
            <span>
                <?php echo $datos['negocios']; ?>
            </span>
        </div>

    </div>

    <!-- TABLA -->

    <div class="tabla-container">

        <?php if($reseñas->num_rows > 0){ ?>

        <table>

            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Negocio</th>
                    <th>Calificación</th>
                    <th>Comentario</th>
                    <th>Fecha</th>
                </tr>
            </thead>

            <tbody>

            <?php while($r = $reseñas->fetch_assoc()){ ?>

                <tr>

                    <td>
                        <?php echo $r['usuario']; ?>
                    </td>

                    <td>
                        <?php echo $r['nombre_negocio']; ?>
                    </td>

                    <td>
                        <?php echo str_repeat("⭐", $r['calificacion']); ?>
                    </td>

                    <td>
                        <?php echo $r['comentario']; ?>
                    </td>

                    <td>
                        <?php echo $r['fecha']; ?>
                    </td>

                </tr>

            <?php } ?>

            </tbody>

        </table>

        <?php } else { ?>

            <div class="sin-reseñas">

                <i class="fa-regular fa-star"></i>

                <h3>Aún no hay reseñas</h3>

                <p>
                    Las reseñas aparecerán aquí cuando los usuarios
                    califiquen los negocios.
                </p>

            </div>

        <?php } ?>

    </div>

</div>

</body>
</html>