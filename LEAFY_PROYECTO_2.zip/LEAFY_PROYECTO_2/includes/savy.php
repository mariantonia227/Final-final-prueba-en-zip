<!-- SAVY BOTÓN -->
<div id="savy-btn">
    <img src="assets/savy.png" alt="Savy">
</div>

<!-- CHAT SAVY -->
<div id="savy-chat">

    <div class="savy-header">
        <div class="savy-info">
            <img src="assets/savy.png" alt="Savy">
            <div>
                <h4>Savy</h4>
                <span>Asistente Leafy </span>
            </div>
        </div>

        <button id="cerrar-savy">✕</button>
    </div>

    <div id="savy-mensajes">

        <div class="mensaje savy">
             Hola, soy Savy.

            <br><br>

            Puedo ayudarte a:

            <br> Encontrar ropa
            <br> Recomendar outfits
            <br> Buscar por presupuesto
            <br> Comprar de forma sostenible

            <br><br>

            ¿Qué estás buscando hoy?
        </div>

    </div>

    <div class="savy-sugerencias">
        <button>Outfit casual</button>
        <button>Ropa hombre</button>
        <button>Ropa mujer</button>
    </div>

    <div class="savy-input">
        <input
            type="text"
            id="pregunta"
            placeholder="Escribe un mensaje..."
        >

        <button id="enviar-savy">
            <i class="fa-solid fa-paper-plane"></i>
        </button>
    </div>

</div>