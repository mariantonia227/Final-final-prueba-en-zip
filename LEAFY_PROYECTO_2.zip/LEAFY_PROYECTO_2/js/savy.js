document.addEventListener("DOMContentLoaded", () => {

    const savyBtn = document.getElementById("savy-btn");
    const savyChat = document.getElementById("savy-chat");
    const cerrarSavy = document.getElementById("cerrar-savy");

    if (!savyBtn || !savyChat || !cerrarSavy) {
        console.log("No se encontraron los elementos de Savy");
        return;
    }

    /*ABRIR / CERRAR DESDE EL BOTÓN SAVY*/
    savyBtn.addEventListener("click", () => {

        if (savyChat.classList.contains("active")) {

            /* CERRAR*/
            savyChat.classList.remove("active");
            savyBtn.classList.remove("active");

            setTimeout(() => {
                savyChat.style.display = "none";
            }, 300);

        } else {

            /*ABRIR*/
            savyChat.style.display = "flex";

            setTimeout(() => {
                savyChat.classList.add("active");
                savyBtn.classList.add("active");
            }, 10);

        }

    });

    /*CERRAR CON LA X*/
    cerrarSavy.addEventListener("click", () => {

        savyChat.classList.remove("active");
        savyBtn.classList.remove("active");

        setTimeout(() => {
            savyChat.style.display = "none";
        }, 300);

    });

});

/*MENSAJES SAVY*/

const input = document.getElementById("pregunta");
const botonEnviar = document.getElementById("enviar-savy");
const mensajes = document.getElementById("savy-mensajes");

function agregarMensaje(texto, tipo){

    const div = document.createElement("div");

    div.classList.add("mensaje");
    div.classList.add(tipo);

    div.innerHTML = texto;

    mensajes.appendChild(div);

    mensajes.scrollTop = mensajes.scrollHeight;
}

function responderSavy(texto){

    texto = texto.toLowerCase();

    let respuesta = "";

    if(texto.includes("hola")){

        respuesta = "¡Hola! ¿Cómo puedo ayudarte hoy?";

    }
    else if(texto.includes("hombre")){

        respuesta = "Te recomiendo revisar la categoría Hombre.";

    }
    else if(texto.includes("mujer")){

        respuesta = "Te recomiendo revisar la categoría Mujer.";

    }
    else if(texto.includes("niño") || texto.includes("nino")){

        respuesta = "Puedes encontrar ropa para Niño en la categoría correspondiente.";

    }
    else if(texto.includes("niña") || texto.includes("nina")){

        respuesta = "Puedes encontrar ropa para Niña en la categoría correspondiente.";

    }
    else if(texto.includes("casual")){

        respuesta = "Un outfit casual puede combinar jeans con una camiseta básica.";

    }
    else if(texto.includes("elegante")){

        respuesta = "Para un look elegante puedes buscar prendas de colores neutros y cortes clásicos.";

    }
    else if(texto.includes("barato") || texto.includes("económico")){

        respuesta = "Puedes usar los filtros de precio para encontrar prendas más económicas.";

    }
    else if(texto.includes("sostenible")){

        respuesta = "Comprar ropa de segunda mano ayuda a reducir residuos y alargar la vida útil de las prendas.";

    }
    else if(texto.includes("envio")){

    respuesta = "Puedes consultar los detalles de envío en nuestra sección de ayuda.";

}
else if(texto.includes("favoritos")){

    respuesta = "Puedes guardar productos en favoritos presionando el corazón de cada prenda.";

}
else if(texto.includes("comprar")){

    respuesta = "Puedes añadir productos al carrito y completar tu compra desde allí.";

}
else if(texto.includes("segunda mano")){

    respuesta = "Comprar ropa de segunda mano ayuda a reducir el desperdicio y cuidar el planeta.";

}
else if(texto.includes("devolucion") || texto.includes("devolver")){

    respuesta = "Si tienes dudas sobre devoluciones puedes contactar al vendedor o revisar las políticas de la plataforma.";

}

    else{

        respuesta = "Todavía estoy aprendiendo. Intenta preguntarme sobre ropa, outfits o categorías.";

    }

    setTimeout(() => {
        agregarMensaje(respuesta, "savy");
    }, 500);
}

function enviarMensaje(){

    const texto = input.value.trim();

    if(texto === ""){
        return;
    }

    agregarMensaje(texto, "usuario");

    input.value = "";

    responderSavy(texto);
}

botonEnviar.addEventListener("click", enviarMensaje);

input.addEventListener("keypress", function(e){

    if(e.key === "Enter"){
        enviarMensaje();
    }

});

/* BOTONES RÁPIDOS*/

document.querySelectorAll(".savy-sugerencias button")
.forEach(btn => {

    btn.addEventListener("click", () => {

        const texto = btn.textContent;

        agregarMensaje(texto, "usuario");

        responderSavy(texto);

    });

});